﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dijkstra
{
    internal class Arco
    {
        int _costo;
        char _destinazione, _partenza;

        public Arco(int costo, char destinazione, char partenza)
        {
            _costo = costo;
            _destinazione = destinazione;
            _partenza = partenza;
        }

        public char GetDestinazione
        { 
            get { return _destinazione; }
        }

        public char GetPartenza
        {
            get { return _partenza; }
        }

        public int GetCosto
        {
            get { return _costo; }
            set { _costo = value; }
        }

        public override string ToString()
        {
            return string.Format($"   {_destinazione}   |     {_costo}     |   {_partenza}   ");
        }
    }
}
