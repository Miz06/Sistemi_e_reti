﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dijkstra
{
    internal class Nodo
    {
        private char _hostname;
        bool _stato;
        List<Arco> _archi = new List<Arco>();

        public Nodo(char hostname, List<Arco> archi)
        {
            _hostname = hostname;
            _stato = true;
            _archi.AddRange(archi);
        }

        public char GetHostname
        {
            get { return _hostname; }
        }

        public List<Arco> GetArchi
        {
            get { return _archi; }
        }

        public override string ToString()
        {
            return string.Format($"Hostname: {_hostname} - Stato: {_stato}");
        }

        public void SortArchi()//Metodo di riordinamento degli archi in base al costo
        {
            _archi.Sort((a1, a2) => a1.GetCosto.CompareTo(a2.GetCosto));
        }
    }
}
