﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Dijkstra
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Per il corretto funzionamento dell'algoritmo è necessario specificare tutti i nodi presenti nella rete e i valori dei loro archi.
            //Per terminare l'inserimento inserire '!' al momento dell'inserimento del nodo o del nodo adiacente

            List<Nodo> nodi = new List<Nodo>(); //nodi della rete
            List<Arco> nodiVisitati = new List<Arco>(); //cammini minimi

            //Lista e variabili necessarie all'inserimento dei nodi
            List<Arco> archi = new List<Arco>();
            char nameNodo = '\0', nodoAdiacente = '\0';
            int costo = -1;

            //Variabile di controllo
            bool valid;

            int scelta;
            string[] menu = new string[] { "Visualizza nodi", "Visualizza tabella finale dei costi", "Esci" };

            do
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("=> IL PRIMO NODO INSERITO VIENE CONSIDERATO COME NODO DI PARTENZA: ");
                nodi.ForEach(n => Console.Write($" [{n.GetHostname}] "));

                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\n\n[INSERIRE I PARAMETRI DEL NODO ('!' to end)]");
                Console.ForegroundColor = ConsoleColor.White;

                archi.Clear();//Rimuovo gli elementi presenti nella lista dall'inserimento precedente

                //Inserimento di un nodo
                do
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("\n=> Nodo: ");
                    Console.ForegroundColor = ConsoleColor.White;

                    valid = InserimentoNodo(ref nameNodo);
                    if (!valid)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(">> Inserire un carattere valido");
                    }
                } while (!valid);

                if (nameNodo != '!' && !nodi.Exists(e => e.GetHostname == nameNodo))
                {
                    do
                    {
                        //Inserimento del nodo adiacente
                        do
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.Write("\n=> Inserire il nodo adiacente: ");
                            Console.ForegroundColor = ConsoleColor.White;

                            valid = InserimentoNodo(ref nodoAdiacente);

                            if (!valid)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine(">> Inserire un carattere valido");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                        } while (!valid);

                        if (nodoAdiacente != '!' && nodoAdiacente != nameNodo && !archi.Exists(e => e.GetDestinazione == nodoAdiacente))
                        {
                            //Inserimento del costo per giungere al nodo adiacente
                            do
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.Write($"\n=> Inserire il costo per giugere al nodo {nodoAdiacente}: ");
                                Console.ForegroundColor = ConsoleColor.White;

                                valid = InserimentoCosto(ref costo);

                                if (!valid)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(">> Inserire un numero intero maggiore di 0");
                                    Console.ForegroundColor = ConsoleColor.White;
                                }
                                else
                                {
                                    for (int i = 0; i < nodi.Count && valid; i++)
                                    {
                                        valid = ControlloCosti(nodi[i], new Arco(costo, nodoAdiacente, nameNodo));

                                        if (!valid)
                                        {
                                            Console.ForegroundColor = ConsoleColor.Red;
                                            Console.WriteLine($"Il costo per giungere al nodo {nodoAdiacente} non è coerente con il costo per giungere al nodo {nameNodo} specificato in precedenza");
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                    }
                                }

                            } while (!valid);

                            archi.Add(new Arco(costo, nodoAdiacente, nameNodo));
                        }
                        else
                        {
                            if (nodoAdiacente != '!')
                            {
                                Console.ForegroundColor = ConsoleColor.Red;

                                if (nodoAdiacente == nameNodo)
                                {
                                    Console.WriteLine($">> Il nodo specificato come nodo adiacente ({nodoAdiacente}) è lo stesso nodo da cui parte l'arco {nameNodo}");
                                }
                                else
                                {
                                    Console.WriteLine($">> L'arco per giungere al nodo adiacente {nodoAdiacente} è già stato specificato");
                                }

                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            else
                            {
                                for (int i = 0; i < nodi.Count && valid; i++)
                                {
                                    valid = ControlloArchi(nodi[i], new Nodo(nameNodo, archi));
                                    if (!valid)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("Il nodo risulta essere assente di uno o più collegamenti specificati in altri nodi precedentemente");
                                        Console.ForegroundColor = ConsoleColor.White;
                                    }
                                }
                            }
                        }
                    } while (nodoAdiacente != '!' || !valid);

                    nodi.Add(new Nodo(nameNodo, archi));
                }
                else
                {
                    if (nameNodo != '!')
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine($"Il nodo {nameNodo} è già stato inserito");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }

                Console.Clear();
            } while (nameNodo != '!');

            nodi[0].GetArchi.Add(new Arco(0, nodi[0].GetHostname, '-')); //Aggiungo al nodo di partenza un arco con costo 0
            nodi.ForEach(e => e.SortArchi()); //Sort degli archi in ogni nodo

            nodiVisitati.Clear();
            PopolaTabellaCosti(nodi, nodiVisitati); //Chiamata al metodo che si occupa della popolazione della tabella finale dei costi

            do
            {
                do//MENU' DI SCELTA
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine("[MENU']");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("----------------------------");
                    for (int i = 0; i < menu.Length; i++)
                    {
                        Console.WriteLine($"[{i + 1}] {menu[i]}");
                    }
                    Console.WriteLine("----------------------------");
                    Console.Write("Scelta: ");
                } while (!int.TryParse(Console.ReadLine(), out scelta) || scelta < 1 || scelta > menu.Length);

                Console.Clear();

                switch (scelta)
                {
                    case 1://STAMPO GLI ATTRIBUTI DEI NODI
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("[NODI DELLA RETE]");
                        Console.ForegroundColor = ConsoleColor.White;

                        for (int i = 0; i < nodi.Count; i++)
                        {
                            Console.WriteLine("----------------------------");
                            Console.WriteLine(nodi[i].ToString());
                            Console.WriteLine("----------------------------");
                            nodi[i].GetArchi.ForEach(e => Console.WriteLine(e.ToString()));
                            Console.WriteLine("----------------------------\n");
                        }

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Premere invio per tornare al menù di scelta");
                        Console.ForegroundColor = ConsoleColor.White;

                        Console.ReadLine();
                        break;

                    case 2: //STAMPO LA TABELLA FINALE DEI COSTI
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine("[TABELLA FINALE DEI COSTI]");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("----------------------------");
                        Console.WriteLine("   A   |   COSTO   |   DA   ");
                        Console.WriteLine("----------------------------");
                        nodiVisitati.ForEach(e => Console.WriteLine(e.ToString()));
                        Console.WriteLine("----------------------------\n");

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.WriteLine("Premere invio per tornare al menù di scelta");
                        Console.ForegroundColor = ConsoleColor.White;

                        Console.ReadLine();
                        break;
                }
                Console.Clear();
            } while (scelta != 3);
        }

        public static void PopolaTabellaCosti(List<Nodo> nodi, List<Arco> nodiVisitati)
        {
            List<Arco> temp = new List<Arco>(); //archi dei singoli nodi che vengono analizzati 

            for (int i = 0; i < nodi.Count; i++)
            {
                if (i == 0)
                {
                    nodi[0].GetArchi.ForEach(a => temp.Add(a)); //AGGIUNGO ALLA TABELLA TEMPORANEA GLI ARCHI DEL NODO DI PARTENZA
                }
                else
                {
                    nodi.Find(e => e.GetHostname == temp[0].GetDestinazione).GetArchi.ForEach(a => temp.Add(a)); //AGGIUNGO ALLA TABELLA TEMPORANEA GLI ARCHI DEL NODO DEFINITO COME DESTINAZIONE NELL'ULTIMO NODO INDAGATO

                    for (int j = 0; j < temp.Count; j++)
                    {
                        if (nodiVisitati[i - 1].GetDestinazione == temp[j].GetDestinazione)//NON CONSIDERO L'ARCO IN QUANTO GIA' VISITATO
                        {
                            temp.RemoveAt(j);
                        }
                    }

                    for (int j = 0; j < temp.Count; j++)
                    {
                        if (nodiVisitati[i - 1].GetDestinazione == temp[j].GetPartenza)
                        {
                            // Crea una copia dell'arco corrente in temp in quanto se avessi modificato direttamente il campo arco del nodo in temp avrei di conseguenza modificato anche la lista contenente tutti i nodi della rete
                            Arco tempArco = new Arco(temp[j].GetCosto, temp[j].GetDestinazione, temp[j].GetPartenza);
                            tempArco.GetCosto += nodiVisitati[i - 1].GetCosto;
                            temp[j] = tempArco;
                        }
                    }
                }

                for (int k = 0; k < temp.Count; k++)//Rimuovo doppioni o nodi con stessa destinazione ma costo magggiore
                {
                    for (int j = k; j < temp.Count - 1; j++)
                    {
                        if (temp[k].GetDestinazione == temp[j + 1].GetDestinazione && temp[k].GetCosto > temp[j + 1].GetCosto)
                        {
                            temp.RemoveAt(k);
                        }
                        else if (temp[k].GetDestinazione == temp[j + 1].GetDestinazione && temp[k].GetCosto <= temp[j + 1].GetCosto)
                        {
                            temp.RemoveAt(j + 1);
                        }
                    }
                }

                nodiVisitati.Add(temp[0]); //aggiungo il nodo indagato nella tabella dei visitati
                temp.RemoveAt(0); //rimuovo il nodo indagato

                temp.Sort((a1, a2) => a1.GetCosto.CompareTo(a2.GetCosto)); //riordino la tabella temporanea

                for (int k = 0; k < nodiVisitati.Count; k++)
                {
                    for (int j = 0; j < temp.Count; j++)
                    {
                        if (nodiVisitati[k].GetDestinazione == temp[j].GetDestinazione)
                        {
                            temp.RemoveAt(j);
                        }
                    }
                }
            }
        }

        public static bool InserimentoNodo(ref char nameNodo)
        {
            if (!char.TryParse(Console.ReadLine(), out nameNodo) || nameNodo == '\0')
                return false;
            else
                return true;
        }

        public static bool InserimentoCosto(ref int costo)
        {
            if (!int.TryParse(Console.ReadLine(), out costo) || costo < 0)
                return false;
            else
                return true;
        }

        public static bool ControlloArchi(Nodo n, Nodo nodoSupporto)
        {//il metodo controlla la coerenza tra gli archi dei nodi 
            bool v = false, v2 = false;
            int c = 0;

            for (int i = 0; i < n.GetArchi.Count; i++)
            {
                if (n.GetArchi[i].GetDestinazione == nodoSupporto.GetHostname)
                {
                    foreach (Arco a in nodoSupporto.GetArchi)
                    {
                        if (a.GetDestinazione == n.GetHostname)
                        {
                            i = n.GetArchi.Count;
                            v = true;
                        }
                    }
                }
                else
                {
                    v2 = true;
                    c++; //il contatore consente di individuare il caso in cui non tutte le destinazioni siano uguali al nome del nodo che si vuole inserire
                }
            }

            if ((!v2 && !v) || (v2 && !v && c != n.GetArchi.Count))
                return false;
            else
                return true;
        }

        public static bool ControlloCosti(Nodo n, Arco a)
        {
            bool v = true;

            for (int i = 0; i < n.GetArchi.Count; i++)
            {
                if (n.GetArchi[i].GetDestinazione == a.GetPartenza && a.GetDestinazione == n.GetHostname)
                {
                    if (a.GetCosto == n.GetArchi[i].GetCosto)
                    {
                        v = true;
                    }
                    else
                    {
                        i = n.GetArchi.Count;
                        v = false;
                    }
                }
            }

            return v;
        }
    }
}